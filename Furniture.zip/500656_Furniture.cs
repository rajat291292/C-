﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _500656_Furniture
{

    //Interface
    public interface Ivat
    {
        double cal_vat(double i);
    }


    public class Furniture
    {
        public string Name { get; set; }
        public int furniturecode;
        // To make read only
        public int FurnitureCode
        {
            get
            {
                return furniturecode;
            }
        }
        public int noofModels { get; set; }
        public string Category { get; set; }
        public int seats;


    }

    class Model : Furniture
    {
        public int id { get; set; }
        public string model { get; set; }
        public double price { get; set; }
        public Boolean instock { get; set; }

        static int stock;
        int flag1 = 0;
        int ustock;
        int count = 0;

        //Constructor
        public Model()
        {

        }

        //Parameterized Constructor
        public Model(int a, string m, double p, Boolean b)
        {
            this.id = a;
            this.model = m;
            this.price = p;
            this.instock = b;
        }

        static public List<Model> list = new List<Model>();

        double cal_vat(double i)
        {
            return (i * .045);
        }

        public override string ToString()
        {
            Console.WriteLine(Convert.ToString(id));
            Console.WriteLine(Convert.ToString(price));
            Console.WriteLine(Convert.ToString(model));
            Console.WriteLine(Convert.ToString(instock));
            return null;

        }

        public void add_model()
        {

            Model mod = new Model();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n*Add New Model*\n");
            Console.WriteLine("Enter Funiture Category \n1 Dining Table \n2 Sofa Set \n3 Dressing Table");
            int catogery = Convert.ToInt32(Console.ReadLine());

            if (catogery == 1)
            {
                mod.Category = "Dining Table";
            }
            else if (catogery == 2)
            {
                mod.Category = "Sofa Set";
            }

            else if (catogery == 3)
            {
                mod.Category = "Dressing Table";
            }

            else
            {
                Console.WriteLine("\nWrong Choice press any key to add again");
                Console.ReadKey();
                new Model().add_model();
            }
            Console.WriteLine("Enter Model Name:");

            string modelname = Console.ReadLine();

            foreach (char c in modelname)
            {
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')))
                {
                    Console.WriteLine("Enter Only Alphabets");
                    break;
                }

                else
                {
                    mod.Name = modelname;
                    Random r = new Random();
                    mod.furniturecode = r.Next(400, 600);
                    Console.WriteLine("\n Furniture code is:" + mod.furniturecode);
                    mod.id = r.Next(1, 100);
                    Console.WriteLine("\n Furniture ID is:" + mod.id);
                    Console.WriteLine("\nPlease enter the price:");
                    mod.price = Convert.ToDouble(Console.ReadLine());

                    double vat = cal_vat(mod.price);
                    Console.WriteLine("\n Your VAT is:" + vat);

                    Console.WriteLine("\nEnter no of Seats:");
                    mod.seats = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nEnter the no of stock:");
                    stock = Convert.ToInt32(Console.ReadLine());
                    mod.ustock = stock;
                    list.Add(mod);
                    return;
                }
            }
        }
        public void delete_model()
        {
            int choice;
            Console.WriteLine("\n *  Deleting aModel  * ");
            Console.WriteLine(" \nEnter the model ID  that to be removed:");
            choice = Convert.ToInt32(Console.ReadLine());


            foreach (Model dm in list)
            {
                if (dm.id == choice)
                {
                    list.Remove(dm);
                    count = count + 1;
                    dm.ustock--;
                    break;
                }
            }
            if (count == 0)
            {
                Console.WriteLine("Id Not Found");
            }

        }

        public void display_all_models()
        {
            foreach (Model obj in list)
            {
                Console.WriteLine(obj.id);
                Console.WriteLine(obj.Category);
                Console.WriteLine(obj.furniturecode);
                Console.WriteLine(obj.Name);
                Console.WriteLine(obj.price);

            }
        }
        public void modify_price()
        {
            Console.WriteLine("\nEnter the id of the item:");
            int tempid = Convert.ToInt32(Console.ReadLine());
            foreach (Model li in list)
            {
                if (li.id == tempid)
                {
                    Console.WriteLine("Enter the Price ");
                    int price = Convert.ToInt32(Console.ReadLine());
                    li.price = price;
                    break;
                }
            }
        }
        public void lowest_price()
        {
            double min = 10000000000;
            foreach (Model a in list)
            {
                if (a.price < min)
                {
                    min = a.price;
                }
            }

            Console.WriteLine("the lowest price is {0}", min);
        }



        public void modelsln_Aprice_range()
        {
            Console.WriteLine("Please Enter the Start Price Range");
            double start = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please Enter the End Price Range");
            double end = Convert.ToDouble(Console.ReadLine());
            foreach (Model cc in list)
            {
                if (cc.price >= start && cc.price <= end)
                {

                    Console.WriteLine("furniture code" + cc.furniturecode);
                    Console.WriteLine(" model name is" + cc.Name);
                    Console.WriteLine("price:{0}", cc.price);
                }
                else
                {
                    Console.WriteLine("Not in Range");
                }
            }

        }
        public void display_1model()
        {
            Console.WriteLine("Enter the product Id to display details");
            int temp1 = Convert.ToInt32(Console.ReadLine());

            foreach (Model cc in list)
            {
                if (cc.id == temp1)
                {
                    Console.WriteLine(cc.id);
                    Console.WriteLine(cc.Category);
                    Console.WriteLine(cc.furniturecode);
                    Console.WriteLine(cc.Name);
                    Console.WriteLine(cc.price);
                }
            }

        }
        public void check_availability()
        {
            Console.WriteLine("Enter the product Id to check the stock");
            int prodtemp = Convert.ToInt32(Console.ReadLine());

            foreach (Model cc in list)
            {
                if (cc.id == prodtemp)
                {
                    if (cc.ustock > 0)
                    {
                        Console.WriteLine("Stocks Are Available");
                        flag1 = flag1 + 1;
                    }

                }
            }
            if (flag1 == 0)
            {
                Console.WriteLine("Stocks are not Available");
            }
        }


        class Program
        {
            static void Main(string[] args)
            {
                char choic;
                do
                {
                    Model add = new Model();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\n **FURNITURE DEALER APPLICATION**");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\n1 Add New Model\n2 Delete a Model\n3 Display All Models\n4 Modify the Price\n5 Lowest_price \n6. Models in a price Range\n7 Price of a specific model\n8.Check for Availability ");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            add.add_model();
                            break;
                        case 2:

                            add.delete_model();
                            break;
                        case 3:
                            add.display_all_models();
                            break;
                        case 4:

                            add.modify_price();
                            break;
                        case 5:
                            add.lowest_price();
                            break;
                        case 6:
                            add.modelsln_Aprice_range();
                            break;
                        case 7:
                            add.display_1model();
                            break;
                        case 8:
                            add.check_availability();
                            break;


                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nDo You want to continue with the console (Y or N)?\n");
                    choic = Convert.ToChar(Console.ReadLine());
                } while ((choic == 'y') || (choic == 'Y'));
            }
        }
    }
}


