﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using caseletBanking;

namespace ConsoleApplication10
{
      class currentaccount : account, Itransaction, IROI
        {
            public double amount; int i = 1;
            public string typeofaccount = "Current account";
            public double MinBalanceRequired = 1000;
           public List<currentaccount> register1 = new List<currentaccount>();
            List<account> acc = new List<account>();
        // static readonly long num = 18000;
        public void getaccountdetails()
        {
            bool temp = false;
            foreach (currentaccount x in register1)
            {
                temp = true;
                Console.WriteLine("The account holder details are \n");
                Console.WriteLine("TypeofAccount:" + "\t" + x.typeofaccount);
                Console.WriteLine("Account holder name:" + "\t" + x.username);
                Console.WriteLine("Account number:\t" + "\t" + x.accountno);
                Console.WriteLine("Available balance:" + "\t" + x.balance);

            }
            if (temp == false)
            {
                Console.WriteLine("No account to display");
            }
        }
            
        public void getRateofInterest() {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            double GetInterest = 0;

            foreach (var item in register1)
            {
                count++;
                if (item.accountno== numcheck)
                {
                    GetInterest = item.balance * 0.12 * 1;
                    break;
                }
                else if (count == register1.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ForegroundColor = ConsoleColor.White;

                }

            }
            //Console.WriteLine("Enter the rate of Interest ");
            //roi = Convert.ToDouble(Console.ReadLine());
        }
        
        


            public void openaccount()
            {
                currentaccount c = new currentaccount();

            a: Console.WriteLine("Enter the Accountholder name ");
                c.username = Console.ReadLine();
                Console.WriteLine("Enter the Amount to be deposited");
                amount = Convert.ToDouble(Console.ReadLine());
                if (amount < 1000)
                {
                    Console.WriteLine("Minimum amount to open an account is 1000");
                    goto a;
                }
                else
                {
                    c.balance = amount;
                    // c.accountno = num + i++;
                    register1.Add(c);

                    Console.WriteLine("Congrats Your Account has been activated");
                    Console.WriteLine("your Account number is" + c.accountno);
                    //accountno++;

                }

            }

            public void closeaccount(long l)
            {
                bool temp = false;
                foreach (currentaccount s in register1)
                {
                    if (s.accountno == l)
                    {
                        temp = true;
                        if (s.balance > 0)
                        {
                            Console.WriteLine("Account not empty");

                            return;
                        }
                        else if (s.balance == 0)
                        {
                            register1.Remove(s);
                            Console.WriteLine("Account deleted successfully");
                            return;
                        }
                    }
                    if (temp == false)
                    {
                        Console.WriteLine("Invalid account number");
                    }
                }
            }
            public void Editaccount(long acc)
            {
                bool temp = false;
                foreach (currentaccount x in register1)
                {
                    if (x.accountno == acc)
                    {
                        temp = true;
                        Console.WriteLine("Enter the Accountholder name ");
                        x.username = Console.ReadLine();
                        Console.WriteLine("Account holder name is edited");
                    }
                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }
            }
            public void deposit(long acc, double d)
            {
                bool temp = false;
                foreach (currentaccount x in register1)
                {
                    if (x.accountno == acc)
                    {

                        x.balance = x.balance + d;
                        temp = true;
                    }

                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }

            }
            public void withdraw(double acc, double d)
            {
                double minbal = 1000;
                bool temp = false;
                foreach (currentaccount x in register1)
                {
                    if (x.accountno == acc)
                    {
                        temp = true;
                        try
                        {
                            if ((x.balance - d) < minbal)
                            {
                                x.balance = x.balance - d;
                                throw new Exception("Amount is lesser than the minimum balance");
                            }
                            if (x.balance - d == 0)
                            {
                                throw new Exception("Your account balance is 0");
                            }
                            else
                                x.balance = x.balance - d;

                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);

                        }

                    }

                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }

            }
            public void checkbalance(long b)
            {
                bool temp = false;
                foreach (currentaccount x in register1)
                {
                    if (x.accountno == b)
                    {
                        temp = true;
                        Console.WriteLine("Account balance:" + "\t" + x.balance);
                    }

                }
                if (temp == false)
                {
                    Console.WriteLine("Wrong account number");
                }


            }
            public void transferamount()
            {
                long fromaccount, toaccount;
                double amount; bool temp1 = false, temp2 = false;
                Console.WriteLine("Enter your account number");
                fromaccount = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the account number to whom the money has to be transferred ");
                toaccount = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the amount to be transferred");
                amount = Convert.ToDouble(Console.ReadLine());
                foreach (currentaccount x in register1)
                {
                    if (x.accountno == fromaccount)
                    {

                        temp1 = true;
                        if (x.balance - amount >= 0)
                        {
                            foreach (currentaccount y in register1)
                            {
                                if (y.accountno == toaccount)
                                {

                                    temp2 = true;
                                    x.balance = x.balance - amount;
                                    y.balance = y.balance + amount;
                                    Console.WriteLine("Amount transferred");
                                }
                            }
                            if (temp2 == false)
                            {
                                Console.WriteLine("Wrong account number");
                            }

                        }
                        else if (x.balance - amount < 0)
                        {
                            Console.WriteLine("Amount cannot be transferred due to insuffient balance");
                        }
                    }
                }
                if (temp1 == false)
                {
                    Console.WriteLine("Your account number is invalid");
                }

            }
        }
    }

