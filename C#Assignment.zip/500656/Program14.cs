﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class Program
    {
            static void Main(string[] args)
            {

                Bank user1 = new Bank();
                user1.intialValues();
                DisplayMenu();
                Console.WriteLine("Choose the choice of operation");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        user1.depositAmount();
                        break;
                    case 2:
                        user1.withdrawAmount();
                        break;
                }
            }

            static void DisplayMenu()
            {
                Console.WriteLine("Welcome to the Banking system");
            string[] menu =
            {
                "1.Deposit the amount",
                "2.Withdraw the amount"
            };

                for (int i = 0; i < menu.Length; i++)
                {
                    Console.WriteLine(menu[i]);
                }
            }
        }

        class Bank
        {

            public string name;
            public string accountnumber;
            public string accType;
            public double bal;


            public void intialValues()
            {

                Console.WriteLine("Enter the account holder name:");
                name = Console.ReadLine();
                Console.WriteLine("Enter the account number:");
                accountnumber = Console.ReadLine();
                Console.WriteLine("Enter the type of account:");
                accType = Console.ReadLine();
                Console.WriteLine("Enter the amount:");
                bal = int.Parse(Console.ReadLine());
                displayName();

            }


            public void depositAmount()
            {

                Console.WriteLine("Please enter the account number to which the amount is to be deposited");
                string accnumber = Console.ReadLine();

                if (accnumber == accountnumber)
                {
                    Console.WriteLine("Enter the amount to be deposited");
                    bal = bal + double.Parse(Console.ReadLine());
                }

                else
                {
                    Console.WriteLine("The account number is not invalid");

                }
                displayName();
                Console.ReadLine();
            }


            public void withdrawAmount()
            {

                Console.WriteLine("Please enter the account number to which the amount is to be deposited");
                string accnumber = Console.ReadLine();

                if (accnumber == accountnumber)
                {
                    Console.WriteLine("Enter the amount to be withdrawn");
                    double withamt = double.Parse(Console.ReadLine());
                if (bal > withamt)
                    bal = bal - withamt;
                else
                {
                    Console.WriteLine("Insufficient Balance.Please check the balance");
                }  
                }

                else
                {
                    
                    Console.WriteLine("The account number is not invalid");
                    
                }
                displayName();
                Console.ReadLine();
            }


            public void displayName()
            {
                Console.WriteLine($"The bankacoount holder {name} maintaining the balance {bal}");
               
            }
        }
    }

