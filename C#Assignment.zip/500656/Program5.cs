﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dollar
{
    class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("enter the amount in US $");
              double  dollars = Double.Parse(Console.ReadLine());

                double rupees = dollars * 65.9979;
                double pounds = dollars * 0.81;
                Console.WriteLine($"Indian rupees= {rupees} Rupees ");
                Console.WriteLine($"pounds= {pounds} pounds ");
                Console.ReadLine();


            }
        }
}
